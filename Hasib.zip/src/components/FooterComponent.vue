<template>
    <footer>
        <small>Copyright &copy; 2024. Develop by Md Hasibur Rahman</small>
    </footer>
</template>

<script>
    export default {
        
    }
</script>
